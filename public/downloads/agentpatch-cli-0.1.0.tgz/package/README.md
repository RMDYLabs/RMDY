# Agent Patch Protocol CLI

Local-first tools for turning real AI-agent failures into privacy-safe, reproducible regression cases and portable behavior patches.

## Alpha guarantees

- `scan` performs redaction locally and never uploads the original trace.
- Patch packages are declarative YAML plus JSON fixtures; the alpha runner does not execute arbitrary patch code.
- AP-0042 is bundled as the first working behavior patch.
- Everything runs on Node.js 22.13 or newer.

## Install

From the project checkout:

```sh
npm install
npm run build:cli
npm link --workspace @agentpatch/cli
```

## Try it

```sh
apatch scan packages/apatch-cli/examples/failing-trace.json
apatch test AP-0042
apatch install AP-0042
apatch init my-first-patch --id AP-LOCAL-0001
```

`scan` writes a sanitized artifact to `.apatch/cases`. `install` writes verified patch packages to `.apatch/patches` and records versions in `.apatch/installed.json`.

## Patch package

```text
AP-0042/
├── patch.yaml
└── cases/
    └── regression.json
```

The v0.1 runtime supports the declarative `require_tool_arguments` intervention. More intervention types and signed registry resolution come next.
